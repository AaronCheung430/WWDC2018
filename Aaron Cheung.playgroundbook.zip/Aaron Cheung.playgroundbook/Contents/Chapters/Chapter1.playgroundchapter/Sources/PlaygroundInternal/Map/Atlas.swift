import UIKit
import PlaygroundSupport
import AVFoundation

public func _MapBook() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    viewController.view.backgroundColor = .white
    PlaygroundPage.current.liveView = viewController
    
//    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Make sure you are dropping all the nescessary balls"], solution: "Enter 'true' to let the image draggable.\n\nEnter 'false' to let the image not draggeble")
    
    let delayInSeconds = 10.0
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        PlaygroundPage.current.assessmentStatus = .pass(message: "### Congratulations! \nYou have tried to code those images and made them draggable. \n\nYou did very well and please move to [**Next Page**](@next).")    }
//    playBackgroundMusic(filename: "Page Sound Effect.mp3")

}

var backgroundMusicPlayer = AVAudioPlayer()
public func playBackgroundMusic(filename: String) {
    let url = Bundle.main.url(forResource: filename, withExtension: nil)
    guard let newURL = url else {
        print("Could not find file: \(filename)")
        return
    }; do {
        backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
        //        backgroundMusicPlayer.numberOfLoops = -1
        backgroundMusicPlayer.prepareToPlay()
        backgroundMusicPlayer.play()
    } catch let error as NSError {
        print(error.description)
    }
}
