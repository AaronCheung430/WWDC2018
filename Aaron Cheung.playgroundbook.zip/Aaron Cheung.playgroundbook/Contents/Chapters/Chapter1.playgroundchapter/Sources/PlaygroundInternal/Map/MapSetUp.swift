import UIKit
import PlaygroundSupport

public func _MapSetUp() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    viewController.view.backgroundColor = .white
    PlaygroundPage.current.liveView = viewController

    let MapCover = Image(name: "MpaCover.png")
}
