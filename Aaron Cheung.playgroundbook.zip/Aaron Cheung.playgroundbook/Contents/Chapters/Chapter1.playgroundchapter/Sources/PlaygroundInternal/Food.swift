import UIKit
import PlaygroundSupport

public func _Food() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    viewController.view.backgroundColor = .white
    PlaygroundPage.current.liveView = viewController
    
    let table1 = Image(name: "table.png")
    table1.size.width *= 0.4
    table1.size.height *= 0.4
    table1.center.y += 20
    table1.center.x -= 13
    table1.rotation += Double.pi / 4
    
    let table2 = Image(name: "table.png")
    table2.size.width *= 0.4
    table2.size.height *= 0.4
    table2.center.y += 20
    table2.center.x += 13
    table2.rotation -= Double.pi / 4
    
    let table3 = Image(name: "table.png")
    table3.size.width *= 0.4
    table3.size.height *= 0.4
    table3.center.y -= 20
    table3.center.x -= 13
    table3.rotation -= Double.pi / 2
    
    let table4 = Image(name: "table.png")
    table4.size.width *= 0.4
    table4.size.height *= 0.4
    table4.center.y -= 20
    table4.center.x += 13
    
    let table5 = Image(name: "table.png")
    table5.size.width *= 0.4
    table5.size.height *= 0.4
    table5.center.y -= 37
    table5.center.x += 30
    
    let table6 = Image(name: "table.png")
    table6.size.width *= 0.4
    table6.size.height *= 0.4
    table6.center.y -= 37
    table6.center.x -= 30
    
    let table7 = Image(name: "table.png")
    table7.size.width *= 0.4
    table7.size.height *= 0.4
    table7.center.y += 37
    table7.center.x += 30
    
    let table8 = Image(name: "table.png")
    table8.size.width *= 0.4
    table8.size.height *= 0.4
    table8.center.y += 37
    table8.center.x -= 30
    
    let table9 = Image(name: "table.png")
    table9.size.width *= 0.4
    table9.size.height *= 0.4
    table9.center.y += 37
    //table8.center.x -= 30
    
    let table10 = Image(name: "table.png")
    table10.size.width *= 0.4
    table10.size.height *= 0.4
    table10.center.y -= 37
    //table8.center.x -= 30
    
    let table11 = Image(name: "table.png")
    table11.size.width *= 0.4
    table11.size.height *= 0.4
    //table11.center.y -= 37
    table11.center.x -= 30
}


