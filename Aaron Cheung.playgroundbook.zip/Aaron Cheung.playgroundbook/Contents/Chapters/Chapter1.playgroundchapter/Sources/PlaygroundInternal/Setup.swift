import UIKit
import PlaygroundSupport
import AVFoundation

public func _setup() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    viewController.view.backgroundColor = .white
    PlaygroundPage.current.liveView = viewController
//    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Make sure you are dropping all the nescessary balls"], solution: "Enter 'true' to let the image draggable.\n\nEnter 'false' to let the image not draggeble")
    
    let delayInSeconds = 10.0
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
    PlaygroundPage.current.assessmentStatus = .pass(message: "### Congratulations! \nYou have tried to code three parts of Hong Kong and made them draggable. \n\nYou did very well and I am sure that you must understand more with those three parts of Hong Kong. Please go to [**Next Page**](@next).")
        
    }
    
    let image = Image(name: "Hong_Kong_Full_Map.png")
    image.center.y += 18
}
