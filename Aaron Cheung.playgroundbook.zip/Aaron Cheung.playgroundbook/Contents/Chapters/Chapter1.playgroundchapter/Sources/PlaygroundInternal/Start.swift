import UIKit
import PlaygroundSupport
import AVFoundation

public func _start() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    viewController.view.backgroundColor = .white
    PlaygroundPage.current.liveView = viewController

    
    let image = Image(name: "Hong_Kong_Full_Map.png")
    image.center.y += 18
    
    let NT = Image(name: "NT.png")
    NT.center.y -= 20
//    NT.drag = true
    
    let HKIsland = Image(name: "HKisland.png")
    HKIsland.size.width *= 0.27
    HKIsland.size.height *= 0.27
    HKIsland.center.y -= 4
    HKIsland.center.x -= 15
    //HKIsland.drag = true
    
    let Kowloon = Image(name: "Kowloon.png")
    Kowloon.size.width *= 0.2
    Kowloon.size.height *= 0.2
    Kowloon.center.y -= 10
    Kowloon.center.x -= 20
    //Kowloon.drag = true
}
