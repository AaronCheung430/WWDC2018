import UIKit
import PlaygroundSupport
import AVFoundation

var backgroundMusicPlayer1 = AVAudioPlayer()
public func playBackgroundMusicLoop(filename: String) {
    let url = Bundle.main.url(forResource: filename, withExtension: nil)
    guard let newURL = url else {
        print("Could not find file: \(filename)")
        return
    }; do {
        backgroundMusicPlayer1 = try AVAudioPlayer(contentsOf: newURL)
        backgroundMusicPlayer1.numberOfLoops = -1
        backgroundMusicPlayer1.prepareToPlay()
        backgroundMusicPlayer1.play()
    } catch let error as NSError {
        print(error.description)
    }
}

public func _DimSum() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    viewController.view.backgroundColor = .white
    PlaygroundPage.current.liveView = viewController
    
    let delayInSeconds = 15.0
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        PlaygroundPage.current.assessmentStatus = .pass(message: "### Congratulations! \nYou have tried to play the sound that's how Hong Kong people eat, talk and have fun in the Dim Sum Retautant. \n\nYou learnt more about the food culture in Hong Kong. Please go to [**Next Page**](@next).")
        
    }
}
