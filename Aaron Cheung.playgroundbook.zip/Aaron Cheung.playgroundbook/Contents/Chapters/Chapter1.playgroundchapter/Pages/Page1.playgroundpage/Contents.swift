//#-hidden-code
_setup()

let NT = Image(name: "NT.png")
NT.center.y -= 20
//NT.drag = true

let HKIsland = Image(name: "HKisland.png")
HKIsland.size.width *= 0.27
HKIsland.size.height *= 0.27
HKIsland.center.y -= 4
HKIsland.center.x -= 15
//HKIsland.drag = true

let Kowloon = Image(name: "Kowloon.png")
Kowloon.size.width *= 0.2
Kowloon.size.height *= 0.2
Kowloon.center.y -= 10
Kowloon.center.x -= 20
//Kowloon.drag = true

// when the HKIsland.png is touched, make it darker and give it a shadow.
HKIsland.onTouchDown {
    HKIsland.dropShadow = Shadow()
    playBackgroundMusic(filename: "Drag.mp3")

}
// when the touch ends on the HKIsland.png, change its color to a random color.
HKIsland.onTouchUp {
    HKIsland.dropShadow = nil
    playBackgroundMusic(filename: "Drop.mp3")
}
// when the Kowloon.png is touched, make it darker and give it a shadow.
Kowloon.onTouchDown {
    Kowloon.dropShadow = Shadow()
    playBackgroundMusic(filename: "Drag.mp3")
}
// when the touch ends on the Kowloon.png, change its color to a random color.
Kowloon.onTouchUp {
    Kowloon.dropShadow = nil
    playBackgroundMusic(filename: "Drop.mp3")
}
// when the NT.png is touched, make it darker and give it a shadow.
NT.onTouchDown {
    NT.dropShadow = Shadow()
    playBackgroundMusic(filename: "Drag.mp3")
}
// when the touch ends on the NT.png, change its color to a random color.
NT.onTouchUp {
    NT.dropShadow = nil
    playBackgroundMusic(filename: "Drop.mp3")
}
// jump the circle to the point on the canvas that was touched.
//Canvas.shared.onTouchUp {
//    HKIsland.center = Canvas.shared.currentTouchPoints.first!
//    HKIsland.dropShadow = Shadow()
//}
//#-end-hidden-code
/*:
 # [Hong Kong](glossary://hongkong) - 3 parts
 
 Welcome! In this playground, you will know more about the three main parts of Hong Kong. Please try to [REBUILD](glossary://rebuild) those parts of Hong Kong or [RECREATE](glossary://recreate) Hong Kong with your creative ideas.
 - NT: The [New Territories](glossary://newterritories) is in GREEN colour.
 - Kowloon: [Kowloon](glossary://kowloon) is in RED colour.
 - HKIsland: [Hong Kong Island](glossary://hongkongisland) is in BLUE colour.
 */
//: Before you move to the next page, please be sure to tap 'Run My Code' on this page and drag those parts,
/*:
- Type [true](glossary://true) to make those parts draggable!
- Type [false](glossary://false) to make those parts non-draggable!
 */
//: Reminder: You may always check the [Glossary](glossary://glossary) and [Hints](glossary://hints)! They are useful.
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, false, true)
NT.drag = /*#-editable-code*/<#true or false#>/*#-end-editable-code*/
HKIsland.drag = /*#-editable-code*/<#true or false#>/*#-end-editable-code*/
Kowloon.drag = /*#-editable-code*/<#true or false#>/*#-end-editable-code*/

