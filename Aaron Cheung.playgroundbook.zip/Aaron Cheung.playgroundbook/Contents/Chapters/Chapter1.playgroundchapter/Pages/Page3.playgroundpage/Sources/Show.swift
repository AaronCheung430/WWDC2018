//import UIKit
//import PlaygroundSupport
//
//public func Run() {
//    
//    let v = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 700))
//    v.backgroundColor = .white
//    
//    let Left: UIImageView!
//    Left = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 205))
//    Left.center = v.center
//    Left.center.x -= 350
//    Left.image = UIImage(named: "LeftHalf.png")
//    v.addSubview(Left)
//    
//    let Right: UIImageView!
//    Right = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 205))
//    Right.center = v.center
//    Right.image = UIImage(named: "RightHalf.png")
//    Right.center.x += 350
//    v.addSubview(Right)
//    
//    let label: UILabel!
//    label = UILabel(frame: CGRect(x: 0, y: 0, width: 500, height: 100))
//    label.center = v.center
//    label.center.y -= 300
//    label.textAlignment = .center
//    label.text = "Hello World!"
//    label.textColor = UIColor.red
//    label.font = UIFont(name: "Futura Neue", size: 20)
//    label.font = label.font.withSize(30)
//    v.addSubview(label)
//    
//    let Lyrics: UILabel!
//    Lyrics = UILabel(frame: CGRect(x: 0, y: 0, width: 500, height: 100))
//    Lyrics.center = v.center
//    Lyrics.center.y += 300
//    Lyrics.textAlignment = .center
//    Lyrics.text = "Hong Kong SAR 20th Anniversary Theme Song"
//    Lyrics.textColor = UIColor.black
//    Lyrics.font = UIFont(name: "Futura Neue", size: 20)
//    Lyrics.font = Lyrics.font.withSize(20)
//    v.addSubview(Lyrics)
//
//    let delayInSeconds = 2.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
//        label.text = "This is Tsing Ma Bridge."
//        UIView.animate(withDuration: 2, animations: {
//            Left.frame.origin.x += 200
//            Right.frame.origin.x -= 200
//        }, completion: nil)
//    }
//    
////    let delayInSeconds1 = 4.0
////    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds1) {
////        label.text = "Let me tell you some information about it,"
////        label.font = label.font.withSize(20)
////
//////        UIView.animate(withDuration: 2, animations: {
//////            Left.frame.origin.x += 50
//////            Right.frame.origin.x -= 50
//////        }, completion: nil)
////    }
////    "The only way to Hong Kong International Airport."
////    let delayInSeconds3 = 8.0
////    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds3) {
////        label.text = "This Bridge is the..."
////        label.font = label.font.withSize(20)
////        Lyrics.text = "Hello World!"
////
////    }
////
////    let delayInSeconds5 = 10.0
////    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds5) {
////        label.text = "The longest suspension bridge with both rail and road traffic in the world"
////        label.font = label.font.withSize(20)
////    }
////
////    let delayInSeconds6 = 15.0
////    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds6) {
////        label.text = ""
////        label.font = label.font.withSize(15)
////    }
//    
//    let delayInSecondsLyrics = 1.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics) {
//        playBackgroundMusic(filename: "HKSong.mp3")
//    }
//    let delayInSecondsLyrics0 = 3.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics0) {
//        Lyrics.text = "Hong Kong Our Home"
//    }
//    let delayInSecondsLyrics1 = 8.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics1) {
//        Lyrics.text = "That’s why I treasure Hong Kong"
//    }
//    let delayInSecondsLyrics2 = 13.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics2) {
//        Lyrics.text = "That’s why I admire Hong Kong"
//    }
//    let delayInSecondsLyrics3 = 18.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics3) {
//        Lyrics.text = "We love her"
//    }
//    let delayInSecondsLyrics4 = 20.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics4) {
//        Lyrics.text = "with an eternal glowing flame"
//    }
//    let delayInSecondsLyrics5 = 23.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics5) {
//        Lyrics.text = "that grows as time goes by"
//    }
//    let delayInSecondsLyrics6 = 25.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics6) {
//        Lyrics.text = "revealing her true strength"
//    }
//    let delayInSecondsLyrics7 = 27.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics7) {
//        Lyrics.text = "Our beautiful Hong Kong"
//    }
//    let delayInLyrics8 = 30.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInLyrics8) {
//        Lyrics.text = "shining ever brighter"
//    }
//    let delayInSecondsLyrics9 = 32.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics9) {
//        Lyrics.text = "Our beautiful Hong Kong"
//    }
//    let delayInLyrics10 = 35.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInLyrics10) {
//        Lyrics.text = "up on the world stage"
//    }
//    let delayInLyrics11 = 37.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInLyrics11) {
//        Lyrics.text = "Step by step, we will carry on"
//    }
//    let delayInLyrics = 42.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInLyrics) {
//        Lyrics.text = "astounding the world as we always have"
//    }
//    let delayInSecondsLyrics13 = 46.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics13) {
//        Lyrics.text = "Step by step, we will carry on"
//    }
//    let delayInLyrics1 = 52.0
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInLyrics1) {
//        Lyrics.text = "astounding the world as we always have"
//    }
//    let delayInSecondsLyrics15 = 56.5
//    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsLyrics15) {
//        Lyrics.text = "This is our home"
//    }
//    
//    PlaygroundPage.current.liveView = v
//}
