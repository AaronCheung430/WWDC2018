import UIKit
import PlaygroundSupport

let v = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 700))
v.backgroundColor = .white

PlaygroundPage.current.liveView = v
