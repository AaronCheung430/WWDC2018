//#-hidden-code
import UIKit
import PlaygroundSupport

func Run() {

    let v = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 700))
    v.backgroundColor = .white
    
    let Left: UIImageView!
    Left = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 205))
    Left.center = v.center
    Left.center.x -= 350
    Left.image = UIImage(named: "LeftHalf.png")
    v.addSubview(Left)
    
    let Right: UIImageView!
    Right = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 205))
    Right.center = v.center
    Right.image = UIImage(named: "RightHalf.png")
    Right.center.x += 350
    v.addSubview(Right)
    
    let Bridge: UIImageView!
    Bridge = UIImageView(frame: CGRect(x: 0, y: 0, width: 654, height: 223))
    Bridge.center = v.center
    Bridge.image = UIImage(named: "Brige.png")
    
    let Bridge1: UIImageView!
    Bridge1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 654, height: 283))
    Bridge1.center = v.center
    Bridge1.image = UIImage(named: "Brige1km.png")
    
    let Bridge2: UIImageView!
    Bridge2 = UIImageView(frame: CGRect(x: 0, y: 0, width: 500, height: 216))
    Bridge2.center = v.center
    Bridge2.image = UIImage(named: "Brige2km.png")
    
    var Road: UIImageView!
    Road = UIImageView(frame: CGRect(x: 0, y: 0, width: 500, height: 352))
    Road.center = v.center
    Road.center.x += 12
    Road.image = UIImage(named: "road.png")
    
    let Car: UIImageView!
    Car = UIImageView(frame: CGRect(x: 0, y: 0, width: 60, height: 49))
    Car.center = v.center
    Car.image = UIImage(named: "car.png")
    
    let Map: UIImageView!
    Map = UIImageView(frame: CGRect(x: 0, y: 0, width: 500, height: 500))
    Map.center = v.center
    Map.image = UIImage(named: "HKAir.png")
    
    let label: UILabel!
    label = UILabel(frame: CGRect(x: 0, y: 0, width: 500, height: 100))
    label.center = v.center
    label.center.y -= 300
    label.textAlignment = .center
    label.text = "Hello World!"
    label.textColor = UIColor.red
    label.font = UIFont(name: "Futura Neue", size: 20)
    label.font = label.font.withSize(30)
    v.addSubview(label)
    
    let Lyrics: UILabel!
    Lyrics = UILabel(frame: CGRect(x: 0, y: 0, width: 500, height: 100))
    Lyrics.center = v.center
    Lyrics.center.y += 275
    Lyrics.textAlignment = .center
    Lyrics.text = "Hong Kong SAR 20th Anniversary Theme Song"
    Lyrics.textColor = UIColor.black
    Lyrics.font = UIFont(name: "Futura Neue", size: 20)
    Lyrics.font = Lyrics.font.withSize(20)
    v.addSubview(Lyrics)
    
    let Lyrics1: UILabel!
    Lyrics1 = UILabel(frame: CGRect(x: 0, y: 0, width: 500, height: 100))
    Lyrics1.center = v.center
    Lyrics1.center.y += 300
    Lyrics1.textAlignment = .center
    Lyrics1.text = ""
    Lyrics1.textColor = UIColor.black
    Lyrics1.font = UIFont(name: "Futura Neue", size: 20)
    Lyrics1.font = Lyrics.font.withSize(20)
    v.addSubview(Lyrics1)
    
    let delayInSeconds = 2.0
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        label.text = "This is Tsing Ma Bridge."
        UIView.animate(withDuration: 2, animations: {
            Left.frame.origin.x += 200
            Right.frame.origin.x -= 200
        }, completion: nil)
    }
    
    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
        playBackgroundMusic(filename: "HKSong.mp3")
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
        Lyrics.text = "Hong Kong Our Home"
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
        Lyrics.text = "That’s why I treasure Hong Kong"
        Lyrics1.text = "That’s why I admire Hong Kong"
        label.text = "Do you know how long the bridge is?"
        Left.removeFromSuperview()
        Right.removeFromSuperview()
        v.addSubview(Bridge)
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 18) {
        Lyrics.text = "We love her"
        Lyrics1.text = "with an eternal glowing flame"
        label.font = label.font.withSize(20)
        label.text = "The bridge has a main span of 1,377 metres (4,518 ft)"
        v.addSubview(Bridge1)
        Bridge.removeFromSuperview()
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 23) {
        Lyrics.text = "that grows as time goes by"
        Lyrics1.text = "revealing her true strength"
        label.text = "and the total length of the bridge is 2.16 kilometres"
        v.addSubview(Bridge2)
        Bridge1.removeFromSuperview()
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 27) {
        Lyrics.text = "Our beautiful Hong Kong"
        Lyrics1.text = "shining ever brighter"
        label.text = "Do you know how the bridge runs?"
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 32) {
        Lyrics.text = "Our beautiful Hong Kong"
        Lyrics1.text = "up on the world stage"
        label.text = "Here is a photo show how it works!"
        v.addSubview(Road)
        Bridge2.removeFromSuperview()
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 37) {
        Lyrics.text = "Step by step, we will carry on"
        Lyrics1.text = "astounding the world as we always have"
//        label.font = label.font.withSize(17)
        label.text = "The lower level has 2 rail tracks & 2 sheltered lanes"
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 46) {
        Lyrics.text = "Step by step, we will carry on"
        Lyrics1.text = "astounding the world as we always have"
        label.font = label.font.withSize(30)
        label.text = "Let's go to the Airport"
        Road.removeFromSuperview()
        v.addSubview(Map)
        v.addSubview(Car)
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 56.5) {
        Lyrics.text = "This is our home"
        Lyrics1.text = ""
        UIView.animate(withDuration: 2, animations: {
            Car.frame.origin.x -= 150
            Car.frame.origin.y += 60
            Lyrics.frame.origin.y -= 100
        }, completion: nil)
    }
    
    PlaygroundPage.current.liveView = v

    let delayInSecondsShow = 62.0
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSecondsShow) {
        PlaygroundPage.current.assessmentStatus = .pass(message: "### Congratulations! \nThanks for watching the slide show about the [Tsing Ma Bridge](glossary://bridge). \n\nYou have learned things about [Tsing Ma Bridge](glossary://bridge). Please go to [**Next Page**](@next).")
        
    }
}
//#-end-hidden-code
/*:
 # [Tsing Ma Bridge](glossary://bridge)
 
 Welcome to the [Tsing Ma Bridge](glossary://bridge)! You will know more about this famous bridge in Asia.
 I would like to tell you more about the [Tsing Ma Bridge](glossary://bridge), please enjoy the slide show.
 */
//: Before you move to the next page, please be sure to tap 'Run My Code' on this page and drag those parts,
/*:
 - Type [Run](glossary://run) to start the introduction of [Tsing Ma Bridge](glossary://bridge)!
 */
//: Reminder: You may always check up the [Glossary](glossary://glossary) and [Hints](glossary://hints)! They are very useful.
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, Run)
/*#-editable-code*/Run/*#-end-editable-code*/()
