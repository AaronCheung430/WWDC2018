//#-hidden-code
import UIKit
import PlaygroundSupport
import AVFoundation

_DimSum()

let table5 = Image(name: "table.png")
table5.size.width *= 0.4
table5.size.height *= 0.4
table5.center.y -= 37
table5.center.x += 30

let table6 = Image(name: "table.png")
table6.size.width *= 0.4
table6.size.height *= 0.4
table6.center.y -= 37
table6.center.x -= 30

let table7 = Image(name: "table.png")
table7.size.width *= 0.4
table7.size.height *= 0.4
table7.center.y += 37
table7.center.x += 30

let table8 = Image(name: "table.png")
table8.size.width *= 0.4
table8.size.height *= 0.4
table8.center.y += 37
table8.center.x -= 30

let table9 = Image(name: "table.png")
table9.size.width *= 0.4
table9.size.height *= 0.4
table9.center.y += 37
//table8.center.x -= 30

let table10 = Image(name: "table.png")
table10.size.width *= 0.4
table10.size.height *= 0.4
table10.center.y -= 37
//table8.center.x -= 30

let table11 = Image(name: "table.png")
table11.size.width *= 0.4
table11.size.height *= 0.4
//table11.center.y -= 37
table11.center.x -= 30

let DimSumCart = Image(name: "DimSumCart.png")
DimSumCart.size.width *= 0.25
DimSumCart.size.height *= 0.25
DimSumCart.center.x += 20

let table1 = Image(name: "table.png")
table1.size.width *= 0.4
table1.size.height *= 0.4
table1.center.y += 20
table1.center.x -= 13
table1.rotation += Double.pi / 4

let table2 = Image(name: "table.png")
table2.size.width *= 0.4
table2.size.height *= 0.4
table2.center.y += 20
table2.center.x += 13
table2.rotation -= Double.pi / 4

let table3 = Image(name: "table.png")
table3.size.width *= 0.4
table3.size.height *= 0.4
table3.center.y -= 20
table3.center.x -= 13
table3.rotation -= Double.pi / 2

let table4 = Image(name: "table.png")
table4.size.width *= 0.4
table4.size.height *= 0.4
table4.center.y -= 20
table4.center.x += 13

// when the table1.png is touched, make it darker and give it a shadow.
table1.onTouchDown {
    table1.dropShadow = Shadow()
    DimSumCart.center.y = 5
    DimSumCart.center.x = -13

    let delayInSeconds = 0.5
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        playBackgroundMusic(filename: "Siumai.mp3")
        
        let text1 = Text(string: "Siu Mai", fontSize: 20.0, fontName: "Futura", color: .black)
        text1.center.y += 23
        text1.center.x -= 12.7
        
        let One = Image(name: "One.png")
        One.size.width *= 0.17
        One.size.height *= 0.17
        One.center.y += 18
        One.center.x -= 12.7
    }
}
// when the touch ends on the table1.png, change its color to a random color.
table1.onTouchUp {
    table1.dropShadow = nil
}


// when the table2.png is touched, make it darker and give it a shadow.
table2.onTouchDown {
    table2.dropShadow = Shadow()
    DimSumCart.center.y = 5
    DimSumCart.center.x = 13
    
    let delayInSeconds = 0.5
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        playBackgroundMusic(filename: "Dumpling.mp3")
        
        let text2 = Text(string: "Shrimp Dumpling", fontSize: 15.0, fontName: "Futura", color: .black)
        text2.center.y += 23
        text2.center.x += 12.7
        
        let Two = Image(name: "Two.png")
        Two.size.width *= 0.22
        Two.size.height *= 0.22
        Two.center.y += 18
        Two.center.x += 12.7
    }
}
// when the touch ends on the table2.png, change its color to a random color.
table2.onTouchUp {
    table2.dropShadow = nil
}


// when the table3.png is touched, make it darker and give it a shadow.
table3.onTouchDown {
    table3.dropShadow = Shadow()
    DimSumCart.center.y = -5
    DimSumCart.center.x = -13
    
    let delayInSeconds = 0.5
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        playBackgroundMusic(filename: "Bun.mp3")
        
        let text3 = Text(string: "Barbecued Bun", fontSize: 15.0, fontName: "Futura", color: .black)
        text3.center.y -= 17.2
        text3.center.x -= 12.7
        
        let Three = Image(name: "Three.png")
        Three.size.width *= 0.15
        Three.size.height *= 0.15
        Three.center.y -= 22
        Three.center.x -= 13
    }
}
// when the touch ends on the table3.png, change its color to a random color.
table3.onTouchUp {
    table3.dropShadow = nil
}


// when the table4.png is touched, make it darker and give it a shadow.
table4.onTouchDown {
    table4.dropShadow = Shadow()
    DimSumCart.center.y = -5
    DimSumCart.center.x = 13
    
    let delayInSeconds = 0.5
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
        playBackgroundMusic(filename: "Roll.mp3")
        
        let text4 = Text(string: "Vermicelli Roll", fontSize: 15.0, fontName: "Futura", color: .black)
        text4.center.y -= 17.2
        text4.center.x = 13
        
        let Four = Image(name: "Four.png")
        Four.size.width *= 0.2
        Four.size.height *= 0.2
        Four.center.y -= 22
        Four.center.x = 13
    }
}
// when the touch ends on the table4.png, change its color to a random color.
table4.onTouchUp {
    table4.dropShadow = nil
}

// jump the Dim Sum Cart to the point on the canvas that was touched.
Canvas.shared.onTouchUp {
    DimSumCart.center = Canvas.shared.currentTouchPoints.first!
    DimSumCart.dropShadow = Shadow()

    playBackgroundMusic(filename: "CarSound.mp3")
}

func playSound() {
    playBackgroundMusicLoop(filename: "PeopleSound.mp3")
}
//#-end-hidden-code
/*:
 # Food - [Dim Sum](glossary://dimsum)
 
 Welcome to the [Dim Sum](glossary://dimsum) Restaurant! In this Restaurant, you will know more about [Hong Kong](glossary://hongkong) [Dim Sum](glossary://dimsum).
I would like to serve you in the Restaurant, please tap anywhere and let me follow you or tap on those four [tables](glossary://table) to know more about [Hong Kong](glossary://hongkong) [Dim Sum](glossary://dimsum) after tapping 'Run My Code'.
 - [Siu Mai](glossary://siumai) is on top left hand side.
 - [Shrimp Dumpling](glossary://dumpling) is on top right hand side.
 - [Barbecued Bun](glossary://bun) is on bottom left hand side.
 - [Vermicelli Roll](glossary://roll) is on bottom right hand side.
 */
//: Before you move to the next page, please be sure to tap 'Run My Code' this page and type the code below,
/*:
 - Type [PlaySound](glossary://playsound) to play the sound that's people eating to make the restaurant more lively!
*/
//: Reminder: You may always check up the [Glossary](glossary://glossary) and [Hints](glossary://hints)! They are very useful.
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, playSound)
/*#-editable-code*/playSound/*#-end-editable-code*/()
