//#-hidden-code
import UIKit
_MapBook()

func Run() {
    let map = Image(name: "map.png")
    playBackgroundMusic(filename: "PageSoundEffect.mp3")

    // when the map.png is touched, make it darker and give it a shadow.
    map.onTouchDown {
        playBackgroundMusic(filename: "PageSoundEffect.mp3")
        let WorldMap = Image(name: "WorldMap.png")
        
        let HKHint = Image(name: "HKHint.png")
        HKHint.size.width *= 0.3
        HKHint.size.height *= 0.3
        HKHint.center.y += 11.3
        HKHint.center.x += 12.5
        
        let SJHint = Image(name: "SJHint.png")
        SJHint.size.width *= 0.3
        SJHint.size.height *= 0.3
        SJHint.center.y += 15.3
        SJHint.center.x -= 12.7
        
        let delayInSeconds = 1.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayInSeconds) {
            let SJ = Image(name: "HK.png")
            SJ.size.width *= 0.3
            SJ.size.height *= 0.3
            SJ.center.y -= 10
            SJ.center.x += 7
            SJ.drag = true
            let HK = Image(name: "SJ.png")
            HK.size.width *= 0.3
            HK.size.height *= 0.3
            HK.center.y -= 10
            HK.center.x -= 7
            HK.drag = true
            let Plane = Image(name: "Plane.png")
            Plane.size.width *= 0.15
            Plane.size.height *= 0.15
            Plane.center.y += 20
//            Plane.center.x -= 7
            Plane.drag = true
            // when the HK.png is touched, make it darker and give it a shadow.
            HK.onTouchDown {
                HK.dropShadow = Shadow()
                playBackgroundMusic(filename: "Drag.mp3")
            }
            // when the touch ends on the HK.png, change its color to a random color.
            HK.onTouchUp {
                HK.dropShadow = nil
                playBackgroundMusic(filename: "Drop.mp3")
            }
            // when the SJ.png is touched, make it darker and give it a shadow.
            SJ.onTouchDown {
                SJ.dropShadow = Shadow()
                playBackgroundMusic(filename: "Drag.mp3")
            }
            // when the touch ends on the SJ.png, change its color to a random color.
            SJ.onTouchUp {
                SJ.dropShadow = nil
                playBackgroundMusic(filename: "Drop.mp3")
            }
            // when the Plane.png is touched, make it darker and give it a shadow.
            Plane.onTouchDown {
                Plane.dropShadow = Shadow()
                playBackgroundMusic(filename: "Drag.mp3")
            }
            // when the touch ends on the Plane.png, change its color to a random color.
            Plane.onTouchUp {
                Plane.dropShadow = nil
                playBackgroundMusic(filename: "Drop.mp3")
            }
        }
    }
}
//#-end-hidden-code
/*:
 # [Atlas](glossary://atlas)
 
 You still remember what [atlas](glossary://atlas) is, right? Do you know where [Hong Kong](glossary://hongkong) is? In this Atlas, you will know where [Hong Kong](glossary://hongkong) and [San Jose](glossary://sanjose) are on the map.
 - HK: [Hong Kong](glossary://hongkong) is in GREEN colour.
 - SJ: [San Jose](glossary://sanjose) is in RED colour.
 - [Plane](glossary://plane) is the  ✈️.
 */
//: Before you move to the next page, please be sure to tap 'Run My Code' on this page and drag those parts,
/*:
- Type [Run](glossary://run) to start the Atlas!
*/
//: Reminder: You may always check the [Glossary](glossary://glossary) and [Hints](glossary://hints)! They are useful.
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, Run)
/*#-editable-code*/Run/*#-end-editable-code*/()
